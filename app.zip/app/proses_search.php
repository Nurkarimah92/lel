
<?php
    require 'connect.php';
    if(isset($_GET['search'])){

        $search = $_GET['search'];
        $query = mysqli_query($connect, "SELECT * FROM barang WHERE nama_barang LIKE '%".$search."%'");
    }
    while($d = mysqli_fetch_array($query)){
        echo "
        <a href=".$d['id_barang'];">
        <p>".$d['nama_barang'];"</p>
        <p>".$d['deskripsi'];"</p>
        <p>".$d['harga_awal'];"</p>
        </a>";
    }
    header('location:dashboard.php?halaman=beranda');
?>