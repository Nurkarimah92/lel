<?php
require 'connect.php';
$id_barang = $_POST ['id_barang']  ;
$id_user = $_POST ['id_user']  ;
$buyer = $_POST ['buyer']  ;
$seller = $_POST ['seller']  ;
$tgl_berakhir = $_POST ['tgl_berakhir']  ;
$harga_akhir  =$_POST ['harga_akhir'] ;

$insert = mysqli_query($connect, "INSERT INTO lelang VALUES('','$id_barang','$id_user','$buyer','$seller','$tgl_berakhir','$harga_akhir')");
if ( $insert ) {
    header ("location:dashboard.php?halaman=ongoing_lelang&id=$buyer");
} else {
    echo "Terjadi kesalahan!".mysqli_error($connect);
}
