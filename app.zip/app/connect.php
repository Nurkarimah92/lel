<?php
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'db_lelang';
$connect = mysqli_connect($host, $user, $pass, $db);
if ( mysqli_connect_errno()) {
    echo "Terjadi kesalahan pada koneksi database!".mysqli_connect_error($connect);
}
?>