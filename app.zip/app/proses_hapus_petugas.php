<?php
require 'db.php';
$id = $_GET['id'];
$db = new Database();
$delete = $db->delete('petugas', ['id_petugas' => $id]);
if ( $delete > $id ) {
    // Data berhasil dihapus
    header('location:dashboard.php?halaman=tabel_petugas');
} else {
    echo mysqli_error($db->connect());
}
