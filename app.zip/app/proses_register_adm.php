<?php
require 'connect.php';
$id_level = $_POST['id_level'];
$nama_adm = $_POST['nama_adm'];
$username = $_POST['username'];
$password = $_POST['password'];

// Cek apakah akun dengan username sudah terdaftar 
$query  = mysqli_query($connect, "SELECT * FROM adm WHERE username = '$username' ");
// Cek berapa record/data yaang muncul dari query diatas
$result = mysqli_num_rows($query);
// jika sudah terdaftar 

$ekstensi_diperbolehkan	= array('png','jpg','jpeg');
$nama = $_FILES['nama_foto']['name'];
$x = explode('.', $nama);
$ekstensi = strtolower(end($x));
$ukuran	= $_FILES['nama_foto']['size'];
$file_tmp = $_FILES['nama_foto']['tmp_name'];	

if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
    if($ukuran < 1044070){			
        move_uploaded_file($file_tmp, 'file/'.$nama);

if (  $result == 0 ){
    // lanjutkan proses register 
    $hashed_password = password_hash ($password, PASSWORD_DEFAULT);
    // simpan data user ke database
    $insert = mysqli_query($connect, "INSERT INTO adm VALUES ('','$id_level','$nama_adm','$username','$hashed_password','$nama')");
     echo mysqli_error($connect);
     if ( $insert){
        header('location: login_adm.php');
    } else {
         echo " Terjadi Kesalahan Ketika Mendaftarkan Akun, Silahkan Kembali ke Halaman Sebelumnya dan Coba Lagi";
     }
     } else {
        echo " Akun Dengan Username Yang Anda Masukan Sudah Terdaftar, Cobalah Memasukan Username lain.";      
}
    }
}