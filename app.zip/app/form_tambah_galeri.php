<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Title Page-->
    <title>Form Tambah Barang</title>
    <!-- Fontfaces CSS-->
    <link href="assets/css/font-face.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-4.min.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-5.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/mdi-font/assets/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="assets/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="assets/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="assets/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="assets/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="assets/css/tema.css" rel="stylesheet" media="all">
    <link href="assets/css/bootstrap.css" rel="stylesheet" media="all">
</head>

<body>
<?php
include "db.php";
$id = $_GET['id'];
$db = new Database();
$data = $db->getById('masyarakat', ['id_user' => $id]);
foreach($data as $d):
?>
    <div class="content">
        <h2>Form Tambah Foto</h2>
<div class="row row-cols-1 row-cols-md-2">
<div class="col mb-4" >
<!-- <div class="card border-dark" style="max-width:22rem;"> -->
        <form action= "proses_tambah_galeri.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="id_user" value="<?php echo $d ['id_user']; ?>">
            <label>Upload Foto</label>
            <div class="input-group" style="width:300px"><div class="custom-file">
            <label class="custom-file-label"></label>
            <input type="file" name="nama_file" class="custom-file-input"><br>
            </div></div><br>
            <button type="submit" class="btn btn-success">TAMBAH</button>
            </div><br>
            <br>
            <br>
        </form>
    </div>   
    </div>   
    </div>      
<?php endforeach; ?>
</body>
</html>