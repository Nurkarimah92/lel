<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Title Page-->
    <!-- <title>Halaman Admin</title> -->
    <!-- Fontfaces CSS-->
    <link href="assets/css/font-face.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-4.min.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-5.min.css" rel="stylesheet" media="all">
    <link href="assets/mdi-font/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="assets/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="assets/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="assets/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="assets/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <script defer src="assets/vendor/font-awesome-5/svg-with-js/js/fontawesome-all.min.js"></script>
    <!-- Main CSS-->
    <link href="assets/css/tema.css" rel="stylesheet" media="all">
    <link href="assets/css/bootstrap.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="out">
    <div class="wrap">
        <nav class="navbar fixed-top">
                <button class="btn btn-dark" id="menu-toggle"><i class="fas fa-bars fa-2x"></i></button>
            <p style="text-align:left;color:white;">Lelangin</p>
            <!-- <a href="dashboard.php?halaman=home"  class="btn btn-dark">Home</a>
            <a href="dashboard.php?halaman=menu" class="btn btn-dark">Menu</a>
            <a href="dashboard.php?halaman=tentang"  class="btn btn-dark">Tentang</a>
            <a href="dashboard.php?halaman=pesan"  class="btn btn-primary">Pesan</a> -->
            <div>
                <a class="js-acc-btn" style="color:white;" href="dashboard.php?halaman=akun">
                    <i class="zmdi zmdi-account"></i>
                    <?php if ( $_SESSION['id_level'] == 3 ): ?>
                    <?= $_SESSION['username'] ?>
                    <?php endif; ?>
                    <?php if ( $_SESSION['id_level'] == 2 ): ?>
                    <?= $_SESSION['username'] ?><a style="color:white;"> (Petugas)</a>
                    <?php endif; ?>
                    <?php if ( $_SESSION['id_level'] == 1 ): ?>
                    <?= $_SESSION['username'] ?><a style="color:white;"> (Admin)</a>
                    <?php endif; ?>
                </a>
                <?php if ( $_SESSION['id_level'] == 3 ): ?>
                <a style="color:white;" href="logout.php" onclick="return confirm('apakah anda yakin akan keluar?')">Keluar</a>     
                <?php endif; ?>
                <?php if ( $_SESSION['id_level'] <= 2 ): ?>
                <a style="color:white;" href="logout_adm.php" onclick="return confirm('apakah anda yakin akan keluar?')">Keluar</a>     
                <?php endif; ?>
            </div>
            </nav>
            <div class="d-flex" id="wrapper">
                <div class="sidebar">
                    <div class="bg-dark border-right  sidebar sidebar2" id="sidebar-wrapper">
                    <center> <div class="sidebar-heading bg-dark border"> <b></b> </div> </center> 
                    <div class="list-group list-group-flush">
                        <style>
                        b{
                            color:rgb(93, 219, 93);
                        }
                        </style>
                        <a href="dashboard.php?halaman=beranda" class="list-group-item list-group-item-action bg-dark"><b> <b class="zmdi zmdi-home" style="color:white;font-size:20pt;padding-right:5pt;"></b>Beranda</b></a>
                        <?php if ( $_SESSION['id_level'] <= 2 ): ?>
                        <a href="dashboard.php?halaman=tabel_barang" class="list-group-item list-group-item-action bg-dark"><b> <b class="zmdi zmdi-chart" style="color:white;font-size:20pt;padding-right:5pt;"></b>Barang</b></a>
                        <?php endif; ?>
                        <?php if ( $_SESSION['id_level'] == 1 ): ?>
                        <a href="dashboard.php?halaman=tabel_adm" class="list-group-item list-group-item-action bg-dark"><b> <b class="zmdi zmdi-badge-check" style="color:white;font-size:20pt;padding-right:5pt;"></b>Adm</b></a>
                        <?php endif; ?>
                        <?php if ( $_SESSION['id_level'] <= 2 ): ?>
                        <a href="dashboard.php?halaman=tabel_user&id=<?= $_SESSION['id_adm']; ?>"" class="list-group-item list-group-item-action bg-dark"><b> <b class="zmdi zmdi-account-circle" style="color:white;font-size:20pt;padding-right:5pt;"></b>Tabel User</b></a>
                        <a href="dashboard.php?halaman=akun_adm&id=<?= $_SESSION['id_adm']; ?>"" class="list-group-item list-group-item-action bg-dark"><b> <b class="zmdi zmdi-account" style="color:white;font-size:20pt;padding-right:5pt;"></b>Akun</b></a>
                        <?php endif; ?>
                        <?php if ( $_SESSION['id_level'] == 3 ): ?>
                        <a href="dashboard.php?halaman=akun&id=<?= $_SESSION['id_user']; ?>" class="list-group-item list-group-item-action bg-dark"><b> <b class="zmdi zmdi-account-circle" style="color:white;font-size:20pt;padding-right:5pt;"></b>Akun</b></a>
                        <a href="dashboard.php?halaman=lelang&id=<?= $_SESSION['id_user']; ?>" class="list-group-item list-group-item-action bg-dark"><b> <b class="zmdi zmdi-money-box" style="color:white;font-size:20pt;padding-right:5pt;"></b>Lelang</b></a>
                        <?php endif; ?>
                        <a href="dashboard.php?halaman=tentang" class="list-group-item list-group-item-action bg-dark"><b> <b class="zmdi zmdi-info-outline" style="color:white;font-size:20pt;padding-right:5pt;"></b>Tentang</b></a>
                        <a href="index.php" onclick="return confirm('apakah anda yakin akan keluar?')" class="list-group-item list-group-item-action
                         bg-dark"><b> <b class="zmdi zmdi-long-arrow-return" style="color:white;font-size:20pt;padding-right:5pt;"></b>Keluar</b></a>
                    </div>
                    </div>
                </div>
            </div>
                <div class="content">
                </div>
        <script src="assets/vendor/jquery/jquery.min.js"></script>
        <script src="assets/vendor/bootstrap-4.1/bootstrap.bundle.min.js"></script>
        <script>
        $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
        });
        </script>
        <script src="assets/vendor/bootstrap-4.1/jquery.min.js"> </script>
        <script src="assets/vendor/bootstrap-4.1/popper.min.js"> </script>
        <script src="assets/vendor/bootstrap-4.1/bootstrap.js"> </script>

</body>

            <!-- HEADER DESKTOP-->            <!-- HEADER DESKTOP-->