<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Fontfaces CSS-->
    <link href="assets/css/font-face.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-4.min.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-5.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/mdi-font/assets/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="assets/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="assets/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="assets/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="assets/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="assets/css/tema.css" rel="stylesheet" media="all">
    <style>
        .container p{
        font-size:12pt;
      }
      .container h4{
          font-size:15pt;
      }
    </style>
    <title>Barag Saya </title>
</head>

<body>
    <div class="content">
        <h1>Barang Saya</h1>
        <div class="container">
            <div class="row row-cols-1 row-cols-md-2">
<?php
require 'db.php';
$id = $_GET['id'];
$db = new Database();
$data = $db->getById('barang', ['id_user' => $id]);
$no = 1;
foreach($data as $d):
?>
            <div class="col mb-4" style="max-width:40rem;max-height:40rem;">
            <div class="card card-header bg-dark">
            <a href="barang.php?id=<?php echo $d['id_barang'];?>" style="color:white;"><i id="<?= $no; ?>"></i>
                <p>Berakhir pada tanggal&jam : <br><i style="color:yellow;"><?= $d['tgl']; ?></i></p>
                <h4><?= $d['nama_barang']; ?></h4>
            </div>
            <div class="card card-header">
                <center>
                <img src="<?php echo "file/".$d['nama_file']; ?>" width=250" height="150">
                </center>
            </div>            
            <div class="card card-header bg-dark">
                <p><?= $d['deskripsi']; ?></p>
                <h4>Rp.<?= $d['harga_awal']; ?></h4>
            </a>
            <a href="dashboard.php?halaman=form_update_barang&id=<?php echo $d['id_barang']; ?>" class="btn btn-primary">Update</a><br>
            <a href="proses_hapus_barang.php?id=<?php echo $d['id_barang']; ?>" class="btn btn-danger" onclick="return confirm('apakah anda yakin akan keluar?')">Hapus</a>
            </div>
            </div>
            <?php endforeach; ?>
        </div><br><br>
        </div>
    </div>
    <!-- Jquery JS-->
    <script src="assets/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="assets/vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="assets/vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="assets/vendor/slick/slick.min.js">
    </script>
    <script src="assets/vendor/wow/wow.min.js"></script>
    <script src="assets/vendor/animsition/animsition.min.js"></script>
    <script src="assets/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="assets/vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="assets/vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="assets/vendor/circle-progress/circle-progress.min.js"></script>
    <script src="assets/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="assets/vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="assets/vendor/select2/select2.min.js">
    </script>
    <!-- Main JS-->
    <script src="assets/js/main.js"></script>
</body>
</html>