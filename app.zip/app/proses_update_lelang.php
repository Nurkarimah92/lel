<?php

require 'connect.php';

$id_lelang    = $_POST['id_lelang'];
$id_barang         = $_POST['id_barang'];
$id_user         = $_POST['id_user'];
$buyer       = $_POST['buyer'];
$seller  = $_POST['seller'];
$tgl_berakhir          = $_POST['tgl_berakhir'];
$harga_akhir       = $_POST['harga_akhir'];

$query = mysqli_query($connect, "UPDATE lelang SET id_barang = '$id_barang',
                                id_user = '$id_user',
                                buyer = '$buyer',
                                seller = '$seller',
                                tgl_berakhir='$tgl_berakhir',
                                harga_akhir = '$harga_akhir' 
                                WHERE id_lelang = '$id_lelang'");


if ( $query == TRUE ) {
    header ("location:dashboard.php?halaman=ongoing_lelang&id=$buyer");
} else {
    echo "Terjadi kesalahan...".mysqli_error($connect);
}
?>