<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Title Page-->
    <title>Form Tambah Adm</title>
    <!-- Fontfaces CSS-->
    <link href="assets/css/font-face.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-4.min.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-5.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/mdi-font/assets/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="assets/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="assets/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="assets/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="assets/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="assets/temp/tema1.css" rel="stylesheet" media="all">
    <link href="assets/css/bootstrap.css" rel="stylesheet" media="all">
</head>
<body>
    <div class="wrap">
    <div class="in">
        <h2>Form Tambah Adm </h2>
        <form action= "proses_tambah_adm.php" method="POST">
           <label> ID Level </label><br>
           <select name="id_level" >
           <?php
           require'db.php';
           $db=new Database();
           $level=$db->getAll('level');
           foreach($level as $l):
            ?>
            <option value="<?php echo $l['id_level'];?>"><?php echo $l['level'];?></option>
           <?php endforeach; ?>
            </select>
            <br>
            <label> Nama Adm </label><br>
            <input type="text" name="nama_adm"><br>
           <label>Username </label><br>
           <input type="text" name="username"><br>
           <label>password </label>
           <br>
           <input type="password" name="password"><br>
           <br>
           <button type="submit" class="btn btn-success">TAMBAH</button>
           <br>
           <br>
        </div> 
        </div>   
        </form>
</body>
</html>