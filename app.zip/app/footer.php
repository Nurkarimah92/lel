                        <div class="copyright">
                            <p>Copyright © 2020 SMK Taruna Harapan 1 Cipatat. Designed by XII RPL 1</p>
                        </div>
