<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Title Page-->
    <title>Beranda Lelangin</title>
    <!-- Fontfaces CSS-->
    <link href="assets/css/font-face.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-4.min.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-5.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/mdi-font/assets/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="assets/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="assets/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="assets/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="assets/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="assets/css/tema.css" rel="stylesheet" media="all">
    <link href="assets/css/bootstrap.css" rel="stylesheet" media="all">
    <style>
      .float{
        float:none;
        position:fixed;
        bottom: 10px;
        right: 100px;
        z-index:3;
        background-repeat:no-repeat;
      }
      .container p{
          font-size:10pt;
      }
      .container h4{
          font-size:15pt;
      }
      
    </style>
</head>
<body>
    <div class="content">
        <h1>Beranda</h1><br>
        <form action="proses_search.php" method="GET">
        <div class="input-group" style="width:300px">
        <input type="text" name="cari" placeholder="cari..." class="form-control">
        <div class="input-group-append">
        <input type="submit" name="submit" value="Go!" class="btn btn-outline-secondary">
        </div>
        </div>
        </form><br>
        <div class="container">
            <div class="row row-cols-1 row-cols-2">
    <?php
    require 'db.php';
    $db = new Database();
    $data = $db->getAll('barang');
    $t=date('Y-m-d H:i:s');
    $b='tgl';
    foreach($data as $d):
    ?>
            <div class="col mb-4" style="max-width:40rem;max-height:40rem;">
            <div class="card border-dark">    
                <center>
                <img src="<?php echo "file/".$d['nama_file']; ?>" width="400" height="350">
                </center>
            <div class="card card-header bg-dark">
                <?php if ($d[$b] >= $t): ?>
                <a href="dashboard.php?halaman=barang&id=<?php echo $d['id_barang'];?>" style="color:white;"><i></i>
                <?php endif; ?>
                <?php if ($d[$b] <= $t): ?>
                <a style="color:white;"><i style="color:red;">*EXPIRED</i>
                <?php endif; ?>
                <h4><?= $d['nama_barang']; ?></h4>
                <p><?= $d['deskripsi']; ?></p>
                <h4>Rp.<?= $d['harga_awal']; ?></h4>
            </a>
            </div>

            </div>
            </div>
            <?php endforeach; ?>
        <br><br>
        </div>
        </div>

<script>
var countDownDate = new Date("<?= $d['tgl']; ?>").getTime();
var x = setInterval(function(){
    var now = new Date().getTime();
    var distance = countDownDate - now;
    var days = Math.floor(distance/(1000*60*60*24));
    var hours = Math.floor((distance%(1000*60*60*24))/(1000*60*60));
    var minutes = Math.floor((distance%(1000*60*60))/(1000*60));
    var seconds = Math.floor((distance%(1000*60))/1000);
    document.getElementById("time1").innerHTML = days+"-"+hours+"-"+minutes+"-"+seconds;
    if(distance < 0){
        clearInterval(x);
        document.getElementById("time1").innerHTML = "TEU BISA AKTIF DEUI, HAMPURA EUY:(";
    }
}, 1000);
</script>
            </div>
            </div>

        </div>
    </div>
    <!-- Jquery JS-->
    <script src="assets/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="assets/vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="assets/vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="assets/vendor/slick/slick.min.js">
    </script>
    <script src="assets/vendor/wow/wow.min.js"></script>
    <script src="assets/vendor/animsition/animsition.min.js"></script>
    <script src="assets/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="assets/vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="assets/vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="assets/vendor/circle-progress/circle-progress.min.js"></script>
    <script src="assets/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="assets/vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="assets/vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="assets/js/main.js"></script>

</body>

</html>
<!-- end document-->