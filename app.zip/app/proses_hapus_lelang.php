<?php
require 'db.php';
$id = $_GET['id'];
$db = new Database();
$delete = $db->delete('lelang', ['id_lelang' => $id]);
if ( $delete > 0 ) {
    // Data berhasil dihapus
    header('location:dashboard.php?halaman=akun');
} else {
    echo mysqli_error($db->connect());
}
