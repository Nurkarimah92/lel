<?php
require 'connect.php';
$id_lelang = $_POST ['id_lelang']  ;
$id_barang = $_POST ['id_barang']  ;
$id_user = $_POST ['id_user']  ;
$pembeli = $_POST ['pembeli']  ;
$penjual = $_POST ['penjual']  ;
$tgl_lelang = $_POST ['tgl_lelang']  ;
$penawaran_harga  =$_POST ['penawaran_harga'] ;
$id_status     =$_POST ['id_status'];

$insert = mysqli_query($connect, "INSERT INTO histori_lelang VALUES('','$id_lelang','$id_barang','$id_user','$pembeli','$penjual','$tgl_lelang','$penawaran_harga','$id_status')");
if ( $insert ) {
    header ("location:dashboard.php?halaman=histori_lelang&id=$penjual");
} else {
    echo "Terjadi kesalahan!".mysqli_error($connect);
}
