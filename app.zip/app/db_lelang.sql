-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2020 at 04:54 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.1.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_lelang`
--

-- --------------------------------------------------------

--
-- Table structure for table `adm`
--

CREATE TABLE `adm` (
  `id_adm` int(11) NOT NULL,
  `id_level` int(11) NOT NULL,
  `nama_adm` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `nama_foto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adm`
--

INSERT INTO `adm` (`id_adm`, `id_level`, `nama_adm`, `username`, `password`, `nama_foto`) VALUES
(21, 1, 'jajang tok', 'tok09', '$2y$10$4iTp8Y6TrH2VbEx06jvJFODtLHLVbf/FaVGELQd3VNqUpYAcvcoDy', '3388rw.png'),
(22, 2, 'siti humaira', 'siti4', '$2y$10$JhNGGb8mclc/TB8f18CGeudO0AwbCtD1QE6YBU3ezGiGkUGa83O8y', 'download.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `tgl` datetime NOT NULL,
  `harga_awal` bigint(20) NOT NULL,
  `deskripsi` text NOT NULL,
  `nama_file` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `id_user`, `nama_barang`, `tgl`, `harga_awal`, `deskripsi`, `nama_file`) VALUES
(20, 32, 'sepeda gunung LK', '2020-04-19 00:12:00', 5000000, ' sepeda berkualitas', 'images - 2020-04-17T203507.579.jpeg'),
(21, 33, 'batu akik natural green', '2020-04-19 01:13:00', 500000, ' batu langka', 'images - 2020-04-17T203538.529.jpeg'),
(22, 36, 'headphone sony', '2020-04-19 15:16:00', 100000, 'mantul', 'images - 2020-04-17T203611.031.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `histori_lelang`
--

CREATE TABLE `histori_lelang` (
  `id_history` int(11) NOT NULL,
  `id_lelang` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `pembeli` varchar(50) NOT NULL,
  `penjual` varchar(50) NOT NULL,
  `tgl_lelang` varchar(20) NOT NULL,
  `penawaran_harga` bigint(20) NOT NULL,
  `id_status` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `histori_lelang`
--

INSERT INTO `histori_lelang` (`id_history`, `id_lelang`, `id_barang`, `id_user`, `pembeli`, `penjual`, `tgl_lelang`, `penawaran_harga`, `id_status`) VALUES
(5, 33, 21, 33, 'malik haq', 'yana ferdo', '17-04-2020 16:35:59', 550000, 1);

-- --------------------------------------------------------

--
-- Table structure for table `lelang`
--

CREATE TABLE `lelang` (
  `id_lelang` int(11) NOT NULL,
  `id_barang` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `buyer` varchar(50) NOT NULL,
  `seller` int(11) NOT NULL,
  `tgl_berakhir` varchar(20) NOT NULL,
  `harga_akhir` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lelang`
--

INSERT INTO `lelang` (`id_lelang`, `id_barang`, `id_user`, `buyer`, `seller`, `tgl_berakhir`, `harga_akhir`) VALUES
(33, 21, 33, 'malik haq', 33, '17-04-2020 16:35:59', 550000);

-- --------------------------------------------------------

--
-- Table structure for table `level`
--

CREATE TABLE `level` (
  `id_level` int(11) NOT NULL,
  `level` enum('admin','petugas','user') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `level`
--

INSERT INTO `level` (`id_level`, `level`) VALUES
(1, 'admin'),
(2, 'petugas'),
(3, 'user');

-- --------------------------------------------------------

--
-- Table structure for table `masyarakat`
--

CREATE TABLE `masyarakat` (
  `id_user` int(11) NOT NULL,
  `nama_lengkap` varchar(50) NOT NULL,
  `alamat` text NOT NULL,
  `tgl_lahir` date NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `email` varchar(50) NOT NULL,
  `telp` varchar(20) NOT NULL,
  `bio` text NOT NULL,
  `nama_foto` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `masyarakat`
--

INSERT INTO `masyarakat` (`id_user`, `nama_lengkap`, `alamat`, `tgl_lahir`, `username`, `password`, `email`, `telp`, `bio`, `nama_foto`) VALUES
(32, 'hendra rusmana', 'bandung, cipatat', '2020-04-01', 'hendra01', '$$2y$10$BAWSY4wfMSs96gQ0ozyAae8Lvzg7VNCE8Ftrps/35sdCT8xhl52h', 'hendra@gmail.com', '08176656154', 'penikmat alam', 'ban8r.jpg'),
(33, 'yana ferdo', 'jakarta', '2020-04-02', 'yanafer8', '$2y$10$aLrTqfuezjz.1BYakUybyeEku4xdRNyPWfphlA04euc.pvK.Zu9nG', 'yana@gmail.com', '089726752464', 'penjual batu akik', 'images (6).png'),
(34, 'paijo rustanto', 'lampug', '1998-03-12', 'paijo09', '$2y$10$x6T6zYEMmGI6B8ojyCA/eOlsPS72FtTbTqNRY25E.ih3bI4r1ftri', 'paijo@gmail.com', '083829375167', 'eksplor alam', 'cutout-1586515546.png'),
(35, 'ferdi', 'lampung', '1996-06-11', 'fer87', '$$2y$10$0xFtiA84.Kuek7uqeHk6T.TMLisSHTNbdHv1Otl8bAc11heF0Zw9', 'fer@gmail.com', '083114875678', 'wanderlust', 'op.png'),
(36, 'malik haq', 'lampung', '2003-03-06', 'mal6', '$$2y$10$BUv.U4YGm.fzDgt.PhQZCuRoXvf4dXXNNc0WUrkKRVzjOiI7OeVZ', 'mal@gmail.com', '098754658676', 'hopeless', 'ban8r.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id_status` int(2) NOT NULL,
  `status` varchar(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id_status`, `status`) VALUES
(1, 'sukses'),
(2, 'gagal');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adm`
--
ALTER TABLE `adm`
  ADD PRIMARY KEY (`id_adm`),
  ADD KEY `id_level` (`id_level`);

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `histori_lelang`
--
ALTER TABLE `histori_lelang`
  ADD PRIMARY KEY (`id_history`),
  ADD KEY `id_lelang` (`id_lelang`,`id_user`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_barang` (`id_barang`),
  ADD KEY `id_status` (`id_status`);

--
-- Indexes for table `lelang`
--
ALTER TABLE `lelang`
  ADD PRIMARY KEY (`id_lelang`),
  ADD KEY `id_barang` (`id_barang`),
  ADD KEY `id_user` (`id_user`);

--
-- Indexes for table `level`
--
ALTER TABLE `level`
  ADD PRIMARY KEY (`id_level`);

--
-- Indexes for table `masyarakat`
--
ALTER TABLE `masyarakat`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id_status`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adm`
--
ALTER TABLE `adm`
  MODIFY `id_adm` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `histori_lelang`
--
ALTER TABLE `histori_lelang`
  MODIFY `id_history` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `lelang`
--
ALTER TABLE `lelang`
  MODIFY `id_lelang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `level`
--
ALTER TABLE `level`
  MODIFY `id_level` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `masyarakat`
--
ALTER TABLE `masyarakat`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `id_status` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `adm`
--
ALTER TABLE `adm`
  ADD CONSTRAINT `adm_ibfk_1` FOREIGN KEY (`id_level`) REFERENCES `level` (`id_level`);

--
-- Constraints for table `barang`
--
ALTER TABLE `barang`
  ADD CONSTRAINT `barang_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `masyarakat` (`id_user`);

--
-- Constraints for table `histori_lelang`
--
ALTER TABLE `histori_lelang`
  ADD CONSTRAINT `histori_lelang_ibfk_1` FOREIGN KEY (`id_lelang`) REFERENCES `lelang` (`id_lelang`),
  ADD CONSTRAINT `histori_lelang_ibfk_2` FOREIGN KEY (`id_user`) REFERENCES `masyarakat` (`id_user`),
  ADD CONSTRAINT `histori_lelang_ibfk_3` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`),
  ADD CONSTRAINT `histori_lelang_ibfk_4` FOREIGN KEY (`id_status`) REFERENCES `status` (`id_status`);

--
-- Constraints for table `lelang`
--
ALTER TABLE `lelang`
  ADD CONSTRAINT `lelang_ibfk_2` FOREIGN KEY (`id_barang`) REFERENCES `barang` (`id_barang`),
  ADD CONSTRAINT `lelang_ibfk_3` FOREIGN KEY (`id_user`) REFERENCES `masyarakat` (`id_user`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
