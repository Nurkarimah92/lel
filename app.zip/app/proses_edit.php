<?php
require 'connect.php';

$id_user  = $_POST ['id_user'];
$nama_lengkap  = $_POST ['nama_lengkap'];
$alamat  = $_POST ['alamat'];
$tgl_lahir  = $_POST ['tgl_lahir'];
$username  = $_POST ['username'];
$password  = $_POST ['password'];
$email  = $_POST ['email'];
$telp  = $_POST ['telp'];
$bio  = $_POST ['bio'];
$nama  = $_POST ['nama_foto'];

$ekstensi_diperbolehkan	= array('png','jpg','jpeg');
$nama = $_FILES['nama_foto']['name'];
$x = explode('.', $nama);
$ekstensi = strtolower(end($x));
$ukuran	= $_FILES['nama_foto']['size'];
$file_tmp = $_FILES['nama_foto']['tmp_name'];	

$hashed_password = password_hash ($password, PASSWORD_DEFAULT);

if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
    if($ukuran < 1044070){			
        move_uploaded_file($file_tmp, 'file/'.$nama);
        $query = mysqli_query($connect, "UPDATE masyarakat SET
                                        nama_lengkap ='$nama_lengkap',
                                        alamat ='$alamat',
                                        tgl_lahir ='$tgl_lahir',
                                        username ='$username',
                                        password ='$$hashed_password',
                                        email ='$email',
                                        telp ='$telp',
                                        bio ='$bio',
                                        nama_foto ='$nama'
                                        WHERE id_user ='$id_user'");
        if ( $query == TRUE ) {
            header ("location:dashboard.php?halaman=akun&id=$id_user");
            // {$_SESSION['id_user']}
        }else{
            echo 'GAGAL MENGUPLOAD GAMBAR';
        }
    }else{
        echo 'UKURAN FILE TERLALU BESAR';
    }
}else{
    echo 'EKSTENSI FILE YANG DI UPLOAD TIDAK DI PERBOLEHKAN';
}

