<?php
require 'db.php';
$db = new Database();
$data = $db->getAll('barang');
$i=1;
foreach($data as $d):
?>
        <div class="komoditi">
            <a href="barang.php?id=<?php echo $d['id_barang'];?>">
            <div class="card card-header">
                <p id="time1"></p>
                <p><?= $d['nama_barang']; ?></p>
                <div class="card card-body">
                    <p></p>
                </div>            
            </div>
            <div class="card card-header">
                <p><?= $d['deskripsi']; ?></p>
                <p>Rp.<?= $d['harga_awal']; ?></p>
            </a>
            </div>
        </div><br><br>
            <?php endforeach; ?>

<script>
var countDownDate = new Date("<?= $d['tgl_berakhir']; ?>").getTime();
var x = setInterval(function(){
    var now = new Date().getTime();
    var distance = countDownDate - now;
    var days = Math.floor(distance/(1000*60*60*24));
    var hours = Math.floor((distance%(1000*60*60*24))/(1000*60*60));
    var minutes = Math.floor((distance%(1000*60*60))/(1000*60));
    var seconds = Math.floor((distance%(1000*60))/1000);
    document.getElementById("time1").innerHTML = days+"-"+hours+"-"+minutes+"-"+seconds;
    if(distance < 0){
        clearInterval(x);
        document.getElementById("time1").innerHTML = "TEU BISA AKTIF DEUI, HAMPURA EUY:(";
    }
}, 1000);
</script>