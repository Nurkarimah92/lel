<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Title Page-->
    <title>Form Lelang</title>
    <!-- Fontfaces CSS-->
    <link href="assets/css/font-face.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-4.min.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-5.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/mdi-font/assets/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="assets/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="assets/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="assets/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="assets/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="assets/css/tema.css" rel="stylesheet" media="all">
</head>
<body>
        <div class="content">
            <h1>Konfirmasi Tawaran!</h1>
            <p>Menuju batas waktu : <i id="time1" style="color:red;"></i></p>
            <div class="row row-cols-1 row-cols-md-2">
<?php
if ( isset($_GET['id']) ) {
    $id = $_GET['id'];}
$query = mysqli_query($connect, "SELECT * FROM lelang
                                INNER JOIN barang ON lelang.id_barang = barang.id_barang
                                INNER JOIN masyarakat ON lelang.seller = masyarakat.id_user
                                WHERE id_lelang = '$id'");
$no = '1';
?>       
        <?php if(mysqli_num_rows($query)) {?>
            <?php while ($d = mysqli_fetch_array($query)) {?>

            <div class="col mb-4" >
            <div class="card border-dark">
            <a style="color:black">
                <p>Nama barang : <h4><?= $d['nama_barang']; ?></h4></p>
                <p>Deskripsi : <h4><?= $d['deskripsi']; ?></h4></p>
                <p>Rp.<?= $d['harga_awal']; ?></p>
            </a>
            </div>
            </div>
<div class="col mb-4" >
<div class="card border-dark">
<form action="proses_tawaran.php" method="POST">
    <label>Ditawar Oleh :</label><br>
    <input type="hidden" name="id_lelang" class="form-control" value="<?php echo $d ['id_lelang']; ?>" readonly>
    <input type="hidden" name="id_barang" class="form-control" value="<?php echo $d ['id_barang']; ?>" readonly>
    <div class="input-group" style="width:300px">
    <input type="hidden" name="id_user" class="form-control" value="<?php echo $d ['id_user']; ?>" readonly><br>
    <input type="hidden" name="penjual" class="form-control" value="<?php echo $_SESSION ['nama_lengkap']; ?>" readonly><br>
    </div>
    <div class="input-group" style="width:300px">
    <input type="type" name="pembeli" class="form-control" value="<?php echo $d ['buyer']; ?>" readonly>
    </div>
    <input type="hidden" name="tgl_lelang" class="form-control" value="<?php echo $d['tgl_berakhir']; ?>" readonly>
    <div class="input-group" style="width:300px">
    <p></p><input type="number" name="penawaran_harga" class="form-control" value="<?php echo $d ['harga_akhir']; ?>" readonly><br>
    </div><br>
    <input type="hidden" name="id_status" class="form-control" value="1" readonly>
    <button name="submit" class="btn btn-success">Submit!</button><br><br>
</form>
</div>
</div>
<?php }?>
        <?php }?>

            </div>
        </div>
<script>
var countDownDate = new Date("<?= $d['tgl']; ?>").getTime();
var x = setInterval(function(){
    var now = new Date().getTime();
    var distance = countDownDate - now;
    var days = Math.floor(distance/(1000*60*60*24));
    var hours = Math.floor((distance%(1000*60*60*24))/(1000*60*60));
    var minutes = Math.floor((distance%(1000*60*60))/(1000*60));
    var seconds = Math.floor((distance%(1000*60))/1000);
    document.getElementById("time1").innerHTML = days+"-"+hours+"-"+minutes+"-"+seconds;
    if(distance < 0){
        clearInterval(x);
        document.getElementById("time1").innerHTML = "TEU BISA AKTIF DEUI, HAMPURA EUY:(";
    }
}, 1000);
</script>

    <!-- Jquery JS-->
    <script src="assets/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="assets/vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="assets/vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="assets/vendor/slick/slick.min.js">
    </script>
    <script src="assets/vendor/wow/wow.min.js"></script>
    <script src="assets/vendor/animsition/animsition.min.js"></script>
    <script src="assets/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="assets/vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="assets/vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="assets/vendor/circle-progress/circle-progress.min.js"></script>
    <script src="assets/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="assets/vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="assets/vendor/select2/select2.min.js">
    </script>
    <!-- Main JS-->
    <script src="assets/js/main.js"></script>
</body>
</html>
<!-- end document-->