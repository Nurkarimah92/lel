<?php
session_start();
require 'connect.php';

require 'header.php';

if ( isset($_GET['halaman']) ) {
    $halaman = $_GET['halaman'];

    if ( file_exists("{$halaman}.php") ) {
        require "{$halaman}.php";
    } else {
        require '404.php';
    }

} else {
    require '404.php';
}

require 'footer.php';

