<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Fontfaces CSS-->
    <link href="assets/css/font-face.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-4.min.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-5.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/mdi-font/assets/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="assets/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="assets/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="assets/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="assets/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="assets/css/tema.css" rel="stylesheet" media="all">
    <title>penawaran </title>
</head>
<body>
<?php
if ( isset($_GET['id']) ) {
    $id = $_GET['id'];}
$query = mysqli_query($connect, "SELECT * FROM lelang
                                INNER JOIN barang ON lelang.id_barang = barang.id_barang
                                INNER JOIN masyarakat ON lelang.seller = masyarakat.id_user
                                WHERE nama_lengkap = '$id'");
$no = '1';
?>       
    <div class="content">
        <h1>Penawaran</h1>
        <div class="table-responsive">
        <table  class="table table-bordered table-striped table-hover">
        <thead class="thead-dark">
            <tr>
                <th>No.</th>
                <th>Nama Barang Anda</th>
                <th>Harga Awal</th>
                <th>Aksi</th>
            </tr>
        </thead>
    <tbody>
        <?php if(mysqli_num_rows($query)) {?>
            <?php while ($d = mysqli_fetch_array($query)) {?>
        <tr>
            <td><?= $no++; ?></td>
            <td><?= $d['nama_barang']; ?></td>
            <td>Rp.<?= $d['harga_awal']; ?></td>
            <td>
            <a href="dashboard.php?halaman=detail_lelang&id=<?php echo $d['nama_barang']; ?>" class="btn btn-warning">Lihat Detail
            </a>
            </td>
        </tr>
            <?php }?>
        <?php }?>
    </tbody>
    </table>
    </div>
    </div>
    <!-- Jquery JS-->
    <script src="assets/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="assets/vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="assets/vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="assets/vendor/slick/slick.min.js">
    </script>
    <script src="assets/vendor/wow/wow.min.js"></script>
    <script src="assets/vendor/animsition/animsition.min.js"></script>
    <script src="assets/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="assets/vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="assets/vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="assets/vendor/circle-progress/circle-progress.min.js"></script>
    <script src="assets/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="assets/vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="assets/vendor/select2/select2.min.js">
    </script>
    <!-- Main JS-->
    <script src="assets/js/main.js"></script>
</body>
</html>