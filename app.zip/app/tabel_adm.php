<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Title Page-->
    <title>Tabel adm lelangin</title>
    <!-- Fontfaces CSS-->
    <link href="assets/css/font-face.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-4.min.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-5.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/mdi-font/assets/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="assets/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="assets/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="assets/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="assets/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="assets/css/tema.css" rel="stylesheet" media="all">
    <link href="assets/css/bootstrap.css" rel="stylesheet" media="all">
</head>
<body>
<div class="content">
        <h1 >Tabel Petugas</h1>
    <br>
    <div class="card-body">
        <a href="form_tambah_adm.php" class="btn btn-primary" type="submit">Tambah</a>
    </div>
    <br>
    <div class="table-responsive">
        <table  class="table table-bordered table-striped table-hover">
        <thead class="thead-dark">
            <tr>
                <th>ID Adm </th>
                <th>ID Level</th>
                <th>Nama Adm</th>
                <th>Username</th>
                <th>Password</th>
                <th>Aksi</th>
            </tr>
        </thead>
    <tbody>
            <?php  
            require 'db.php';
            $db = new Database();
            $data = $db->getAll('adm');
            foreach($data as $d):
            ?>
        <tr>
            <td><?= $d['id_adm']; ?></td>
            <td><?= $d['id_level']; ?></td>
            <td><?= $d['nama_adm']; ?></td>
            <td><?= $d['username']; ?></td>
            <td><?= $d['password']; ?></td>
            <td>
            <a href="form_update_petugas.php?id=<?php echo $d['id_adm']; ?>" class="btn btn-primary"> Update</a>
            <a href="proses_hapus_petugas.php?id=<?php echo 
            $d['id_adm'];?>" class="btn btn-danger"
            onclick="return confirm('apakah anda yakin akan menghapus data ini?')">Hapus</a>  
            </td>
        </tr>
            <?php endforeach; ?>
    </tbody>
    </table>
    </div>
    </div>
    </div>
</body>
</html>