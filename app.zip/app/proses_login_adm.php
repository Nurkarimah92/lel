<?php

session_start();
require 'connect.php';
$username = $_POST ['username'];
$password = $_POST ['password'];
// Cek apakah akun yang dimasukan pengguna terdaftar atau tidak
$query = mysqli_query($connect, "SELECT * FROM adm WHERE username = '$username'");
// Cek ada berapa record/data yang muncul dari query diatas
$result = mysqli_num_rows($query);
// Jika akun yang dimasukkan ada
if ( $result == 1 ) {
    // Ambil data user tersebut
    $user = mysqli_fetch_array($query, MYSQLI_ASSOC);
    // Cocokan password
if ( password_verify($password, $user['password']) ) {
    // Simpan data user di session, supaya bisa diakses oleh halaman lain
    $_SESSION = [
        'id_adm' => $user['id_adm'],
        'id_level' => $user['id_level'],
        'nama_adm' => $user['nama_adm'],
        'username' => $user['username'],
        'password' => $user['password'],
        'is_logged_in' => TRUE
    ] ;
    header('location: dashboard.php?halaman=beranda');
} else {
    // Password tidak cocok 
    echo "password yang anda masukkan tidak cocok, periksa kembali penulisannya";
}
} else {
    // Akun tidak ada/terdaftar
    echo "akun yang anda masukkan tidak terdaftar di website kami";
}