<div style="margin-top: 75px; padding: 1em; text-align: center;">
    <h1 style="color: red; font-weight: bold;">404 Not Found</h1>
    <p>Halaman yang anda cari tidak ada,  <a onclick="history.back()" href="">kembali</a> </p>
</div>