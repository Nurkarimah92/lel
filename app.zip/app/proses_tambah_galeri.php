<?php
require 'connect.php';
$id_user = $_POST ['id_user']  ;
// $nama = $_POST ['nama_file']

$ekstensi_diperbolehkan	= array('png','jpg');
$nama = $_FILES['nama_file']['name'];
$x = explode('.', $nama);
$ekstensi = strtolower(end($x));
$ukuran	= $_FILES['nama_file']['size'];
$file_tmp = $_FILES['nama_file']['tmp_name'];	

if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
    if($ukuran < 1044070){			
        move_uploaded_file($file_tmp, 'file/'.$nama);
        $query = mysqli_query($connect, "INSERT INTO galeri VALUES('','$id_user','$nama')");
        if ( $query ) {
            header ("location:dashboard.php?halaman=galeri&id=$id_user");
            // {$_SESSION['id_user']}
        }else{
            echo 'GAGAL MENGUPLOAD GAMBAR';
        }
    }else{
        echo 'UKURAN FILE TERLALU BESAR';
    }
}else{
    echo 'EKSTENSI FILE YANG DI UPLOAD TIDAK DI PERBOLEHKAN';
}

