<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Fontfaces CSS-->
    <link href="assets/css/font-face.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-4.min.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-5.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/mdi-font/assets/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="assets/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="assets/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="assets/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="assets/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="assets/temp/tema1.css" rel="stylesheet" media="all">
    <title>register </title>
</head>
<body>
    <div class="wrap">
    <div class="in">
    <form action="proses_register.php" method="POST" enctype="multipart/form-data">
            <h1>Register</h1>
            <label>Nama Lengkap</label><br>
            <div class="input-group" style="width:300px">
            <input type="text" name="nama_lengkap" class="form-control"><br>
            </div>
            <label>Upload Foto</label>
            <div class="input-group" style="width:300px"><div class="custom-file">
            <label class="custom-file-label"></label>
            <input type="file" name="nama_foto" class="custom-file-input"><br>
            </div></div>
            <label>Alamat</label><br>
            <div class="input-group" style="width:300px">
            <input type="text" name="alamat" class="form-control"><br>
            </div>
            <label>Tanggal Lahir</label><br>
            <div class="input-group" style="width:300px">
            <input type="date" name="tgl_lahir" class="form-control"><br>
            </div>
            <label>Username</label><br>
            <div class="input-group" style="width:300px">
            <input type="text" name="username" class="form-control"><br>
            </div>
            <label>Password</label><br>
            <div class="input-group" style="width:300px">
            <input type="password" name="password" class="form-control"><br>
            </div>
            <label>Email</label><br>
            <div class="input-group" style="width:300px">
            <input type="email" name="email" class="form-control"><br>
            </div>
            <label>Telp</label><br>
            <div class="input-group" style="width:300px">
            <input type="number" name="telp" class="form-control"><br>
            </div>
            <label>Deskripsi/Bio</label><br>
            <div class="input-group" style="width:300px">
            <textarea name="bio" cols="25" rows="5" class="form-control"></textarea><br>
            </div><br>
            <button type="submit" class="btn btn-success">Register</button><br>
            <p>sudah punya akun? login <a href="login.php">disini</a></p>
        </form>
    </div>
    </div>
    <!-- Jquery JS-->
    <script src="assets/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="assets/vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="assets/vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="assets/vendor/slick/slick.min.js">
    </script>
    <script src="assets/vendor/wow/wow.min.js"></script>
    <script src="assets/vendor/animsition/animsition.min.js"></script>
    <script src="assets/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="assets/vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="assets/vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="assets/vendor/circle-progress/circle-progress.min.js"></script>
    <script src="assets/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="assets/vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="assets/vendor/select2/select2.min.js">
    </script>
    <!-- Main JS-->
    <script src="assets/js/main.js"></script>
</body>
</html>