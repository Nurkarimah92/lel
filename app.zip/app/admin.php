<?php
include 'db.php';
$db = new Database();
// $delete = $db->delete('masyarakat',['id_user'=>3]);
// if ( $delete > 0){
//     echo"berhasil";
// }else {
//     echo "gagal..";
// }
// $update = $db->update('masyarakat', [
//     'nama_lengkap'=> 'andri',
//     'username'=> 'andi',
//     'password'=> 'andri',
//     'telp'=> '0765488676763'
// ], ['id_user'=> 3]);
// if ($update > 0) {
//     echo "Berhasil";
// }else{
//     echo"Gagal....";
// }
// $insert = $db->insert('masyarakat', [
//     'id_user'=>'',
//     'nama_lengkap'=> 'saya hackers',
//     'username'=> 'hackers',
//     'password'=> 'hack',
//     'telp'=> '**********'
// ]);
// if ($insert > 0) {
//     echo "Berhasil";
// }else{
//     echo"Gagal....";
// }
// $data = $db->getAll('level');
// foreach($data as $d):
//     echo $d['id_level'];
//     echo "<br>";
//     echo $d['level'];
//     echo "<br>";
//     echo "<hr>";
// endforeach;



