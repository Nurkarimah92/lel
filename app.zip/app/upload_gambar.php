<!DOCTYPE html>
<html>
<head>
	<title>Membuat Upload File Dengan PHP Dan MySQL | www.malasngoding.com</title>
</head>
<body>
	<h1>Membuat Upload File Dengan PHP Dan MySQL <br/> www.malasngoding.com</h1>
	<form action="proses_gambar.php" method="post" enctype="multipart/form-data">
		<input type="file" name="nama_file">
		<input type="submit" name="upload" value="Upload">
	</form>
</body>
</html>