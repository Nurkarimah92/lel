<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Fontfaces CSS-->
    <link href="assets/css/font-face.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-4.min.css" rel="stylesheet" media="all">
    <link href="assets/font-awesome/font-awesome-5.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/mdi-font/assets/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">
    <!-- Bootstrap CSS-->
    <link href="assets/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">
    <!-- Vendor CSS-->
    <link href="assets/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="assets/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="assets/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="assets/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">
    <!-- Main CSS-->
    <link href="assets/css/tema.css" rel="stylesheet" media="all">
    <title>Edit Profil </title>
</head>
<body>
    <div class="content">
<?php
include "db.php";
$id = $_GET['id'];
$db = new Database();
$data = $db->getById('masyarakat', ['id_user' => $id]);
foreach($data as $d):
?>
    <form action="proses_edit.php" method="POST" enctype="multipart/form-data">
            <h1>Register</h1>
            <label>Nama Lengkap</label><br>
            <input type="hidden" name="id_user" class="form-control" value="<?= $d['id_user'];?>"><br>
            <div class="input-group" style="width:300px">
            <input type="text" name="nama_lengkap" class="form-control" value="<?= $d['nama_lengkap'];?>"><br>
            </div>
            <label>Upload Foto</label>
            <div class="input-group" style="width:300px"><div class="custom-file">
            <label class="custom-file-label"></label>
            <input type="file" name="nama_foto" class="custom-file-input" value="<?= $d['nama_foto'];?>"><br>
            </div></div>
            <label>Alamat</label><br>
            <div class="input-group" style="width:300px">
            <input type="text" name="alamat" class="form-control" value="<?= $d['alamat'];?>"><br>
            </div>
            <label>Tanggal Lahir</label><br>
            <div class="input-group" style="width:300px">
            <input type="date" name="tgl_lahir" class="form-control" value="<?= $d['tgl_lahir'];?>"><br>
            </div>
            <label>Username</label><br>
            <div class="input-group" style="width:300px">
            <input type="text" name="username" class="form-control" value="<?= $d['username'];?>"><br>
            </div>
            <label>Password</label><br>
            <div class="input-group" style="width:300px">
            <input type="password" name="password" class="form-control"><br>
            </div>
            <label>Email</label><br>
            <div class="input-group" style="width:300px">
            <input type="email" name="email" class="form-control" value="<?= $d['email'];?>"><br>
            </div>
            <label>Telp</label><br>
            <div class="input-group" style="width:300px">
            <input type="number" name="telp" class="form-control" value="<?= $d['telp'];?>"><br>
            </div>
            <label>Deskripsi/Bio</label><br>
            <div class="input-group" style="width:300px">
            <textarea name="bio" cols="25" rows="5" class="form-control"><?= $d['bio'];?></textarea><br>
            </div><br>
            <button type="submit" class="btn btn-success">EDIT!</button><br>
        </form>
<?php endforeach; ?>
    </div>

    <!-- Jquery JS-->
    <script src="assets/vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="assets/vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="assets/vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="assets/vendor/slick/slick.min.js">
    </script>
    <script src="assets/vendor/wow/wow.min.js"></script>
    <script src="assets/vendor/animsition/animsition.min.js"></script>
    <script src="assets/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="assets/vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="assets/vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="assets/vendor/circle-progress/circle-progress.min.js"></script>
    <script src="assets/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="assets/vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="assets/vendor/select2/select2.min.js">
    </script>
    <!-- Main JS-->
    <script src="assets/js/main.js"></script>

</body>
</html>