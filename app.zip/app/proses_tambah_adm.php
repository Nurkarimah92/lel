<?php
require 'db.php';
$id_level      = $_POST ['id_level']  ;
$nama_adm      = $_POST ['nama_adm']  ;
$username      = $_POST ['username'] ;
$password      = $_POST ['password']   ;

$db = new Database();
$insert = $db->insert('adm', [
    'id_adm'    => '',
    'id_level'      => $id_level,
    'nama_adm'  => $nama_adm,
    'username'      => $username,
    'password'      => $password
]);

if ( $insert > 0 ) {
    // Data berhasil dimasukkan
    header('location:dashboard.php?halaman=tabel_adm');
} else {
    echo mysqli_error($db->connect());
}